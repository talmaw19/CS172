#pragma once
#include <iostream>
#include <cmath>



class EvenNumber
{
private: 
	int value;
public:
	EvenNumber() { value = 0; } // no-arg constructor that creats an object and it assigns EvenNumber for the value of 0
	EvenNumber(int i) { value = i; } // constructs an EvenNumber to a Specified value

	int getValue() { return value; } // whatever number that was enter will equal value
	EvenNumber getNext() { return EvenNumber(value + 2); } // represents the next even number before the current even number in this object
	EvenNumber getPrevious() { return EvenNumber(value - 2); }// represents the even number pervious to the current even number in this object
};






