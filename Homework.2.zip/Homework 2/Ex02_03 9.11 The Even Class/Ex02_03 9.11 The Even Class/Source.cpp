///////////////////////////////
// Tersa Motbaynor Almaw
// CS172 M.Bell 
// HW #2 - Liang Chapter 9:9.11
// The Even Number Class


#include <iostream>
#include <cmath>
#include "Header.h"

using namespace std;

int main()
{
	EvenNumber E1(16); // test program that creates an EvenNumber object for the value of 16 
	cout << E1.getValue() << endl; 
	EvenNumber E2 = E1.getNext();// invokes the even numbers after 16
	cout << E2.getValue()<< endl; //displays the number after
	EvenNumber E3= E1.getPrevious();// invokes the even numbers before 16
	cout << E3.getValue() << endl; //displays the number before 

}