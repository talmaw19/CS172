#pragma once

class Fan
{
private:
	int speed;
	bool on;
	double radius;
public:
	Fan();
	int getSpeed();
	void setTheSpeed(int fanSpeed);
	bool getOn();
	void setOn(bool power);
	double getTheRadius();
	void setTheRadius(double fanRadius);


};


