///////////////////////////////
// Tersa Motbaynor Almaw
// CS172 M.Bell 
// HW #2 - Liang Chapter 9:9.2 
// The Fan Class

#include <iostream>
#include <string>
#include <ctime>
#include "Header.h"
using namespace std;


int main()

{
	// the two fans that we define
	// we use the dot operator in order to set data feild to the object name, which we set as f1 or f2 instead of using the FAN.
	FAN f1; // the first fans radius is being set to 10
	f1.setTheRadius(10);
	f1.setTheSpeed(3); // sets the speed to 3
	f1.setON(true); // and sets the fan on

	FAN f2;
	f2.setTheRadius(5); // sets the radius to 5
	f2.setTheSpeed(2);// sets the speed of the fan to 2 
	f2.setON(false); // and indicates that the fan is off
	
}



