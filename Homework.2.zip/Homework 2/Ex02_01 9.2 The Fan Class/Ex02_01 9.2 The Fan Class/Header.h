#pragma once

#include <iostream>
#include <string>
#include <ctime>
using namespace std;

class FAN
{
private:
	double radius; // data feild, specifies the raidus of the fan.
	int speed; // specifies the speed of the fan.
	bool ON; // indicates wether the fan is on or not.

public:
	FAN()
	{// defult fan
		radius = 5;
		speed = 1;
		ON = false;
	}

	// it refers back to the private, assessors 
	double getRadius() { return radius; }
	int getSpeed() { return speed; }
	bool getON() { return ON; }


	// assignes mutators to private class
	void setTheRadius(int fanRadius)
	{
		if (fanRadius > 0)  // is the new fanRadius is greater than zero then 
		{
			radius = fanRadius; // the new fanRadius is assigned to the radius 
		}
	}

	void setTheSpeed(int fanSpeed)// makes sure that the speed is equal to a valid number
	{
		if (fanSpeed >= 1 && fanSpeed <= 3) // it makes sure that the value that is passed is either 1, 2 or 3
		{
			speed = fanSpeed; // the new speed will equal the new fanspeed
		}
	}

	void setON(bool power)
	{
		ON = power; // indicates that the fan is on or not
	}

};
