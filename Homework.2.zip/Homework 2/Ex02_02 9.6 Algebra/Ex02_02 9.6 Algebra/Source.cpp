///////////////////////////////
// Tersa Motbaynor Almaw
// CS172 M.Bell 
// HW #2 - Liang Chapter 9:9.6 
// The Quadratic Equations Class

#include <ctime>

#include "Header.h"
using namespace std;


int main()
{
	QuadraticEquation Equ1;  
	int a;
	int b;
	int c;

	cout << "Enter a value for A:" << endl; // asks the use to enter a value for a 
	cin >> a; // displays a
	Equ1.setA(a); // this would call the variable that was assigned in the private class 
	cout << "Enter a value for B:" << endl; 
	cin >> b; // displays b
	Equ1.setB(b);// this would call the variable that was assigned in the private class 
	cout << "Enter a value for C:" << endl; 
	cin >> c; // displays c
	Equ1.setC(c);// this would call the variable that was assigned in the private class 

	cout << " Discriminiant is " << Equ1.getDiscriminant() << endl; // discriminant function to be inputed
	cout << "roots";

	if (Equ1.getDiscriminant() >= 0)
	{
		if (Equ1.getDiscriminant() == 0) // makes sure if the discriminant is zero it would only display one root 
		{
			cout << Equ1.getRoot1() << endl;
		}
		else // if the discriminant is positive it  displays 2 roots 

			cout << Equ1.getRoot1() << Equ1.getRoot2() << endl;
	}
	else
		cout << " This equation doesnt have no real roots \n";
}

