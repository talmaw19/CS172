#pragma once
#include <iostream>
#include <cmath>
#include <string>

class QuadraticEquation
{
private: 
	// data feild that represents 3 coefficents.
	int a;
	int b;
	int c;

public:
	QuadraticEquation() // constructor for the arguments a,b,c  
	{
		a, b, c = 1;

	}
	// assigns the get function to  a, b, and c from private 
	int getA() { return a; }
	int getB() { return b; }
	int getC() { return c; }
	
	// constructer arguments 
	void setA(int j) { a = j; }
	void setB(int j) { b = j; }
	void setC(int j) { c = j; }

	int getDiscriminant()
	{
		int k = pow(b, 2) - 4 * a * c; // equation for the Discriminant b^2-4ac
		return k;
	}
	
	double getRoot1() 
	{
		if (getDiscriminant() < 0) // if the discriminant is positive 
		{
			return 0;// it checks to see if the discriminant is equal or less than zero, if it is zeron it returns zero 
		}
		else
		{
			double R1 = (-1 * b + sqrt(getDiscriminant())) / (2 * a); // if it is greater than zero it outputs this. 
			return R1;
		}
	}
	double getRoot2()
	{
		if (getDiscriminant() < 0)
		{
			return 0;
		}
		else 		{
			double R2 = (-1 * b + sqrt(getDiscriminant())) / (2 * a);
			return R2;
		}
	}
	


	


};
